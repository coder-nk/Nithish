"use client";

import { useRef, type KeyboardEvent } from "react";
import { useTheme } from "./ThemeProvider";
import { THEMES, THEME_IDS, type ThemeId } from "@/lib/themes";
import { sound } from "@/lib/audio";

/** Persistent universe switcher — a radiogroup with full keyboard support. */
export function ThemeSwitcher() {
  const { theme, requestTheme, phase, soundOn, toggleSound, lite, setLite, caps } = useTheme();
  const refs = useRef<(HTMLButtonElement | null)[]>([]);

  const pick = (id: ThemeId, el?: HTMLElement | null) => {
    sound?.click();
    const r = el?.getBoundingClientRect();
    requestTheme(
      id,
      r ? { x: (r.left + r.width / 2) / window.innerWidth, y: (r.top + r.height / 2) / window.innerHeight } : undefined,
    );
  };

  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    const i = THEME_IDS.indexOf(theme);
    let n = -1;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") n = (i + 1) % 4;
    if (e.key === "ArrowLeft" || e.key === "ArrowUp") n = (i + 3) % 4;
    if (n >= 0) {
      e.preventDefault();
      refs.current[n]?.focus();
      pick(THEME_IDS[n], refs.current[n]);
    }
  };

  return (
    <nav className="switcher" aria-label="Visual theme">
      <div className="switcher-label" aria-hidden>
        Universe
      </div>
      <div role="radiogroup" aria-label="Choose theme" className="switcher-group" onKeyDown={onKey}>
        {THEME_IDS.map((id, i) => {
          const m = THEMES[id];
          const active = id === theme;
          return (
            <button
              key={id}
              ref={(n) => {
                refs.current[i] = n;
              }}
              role="radio"
              aria-checked={active}
              tabIndex={active ? 0 : -1}
              disabled={phase !== "idle"}
              data-active={active || undefined}
              data-id={id}
              className="switcher-item"
              title={`${m.label} — ${m.hint} (Alt+${m.key})`}
              onClick={(e) => pick(id, e.currentTarget)}
              onPointerEnter={() => sound?.hover()}
            >
              <span className="switcher-swatch" aria-hidden>
                {m.swatch.map((c) => (
                  <i key={c} style={{ background: c }} />
                ))}
              </span>
              <span className="switcher-name">{m.label}</span>
            </button>
          );
        })}
      </div>
      <div className="switcher-tools">
        <button
          className="switcher-tool"
          aria-pressed={soundOn}
          aria-label={soundOn ? "Mute sound" : "Enable ambient sound"}
          title={soundOn ? "Sound on" : "Sound off"}
          onClick={toggleSound}
        >
          <span className="eq" data-on={soundOn || undefined} aria-hidden>
            <i />
            <i />
            <i />
            <i />
          </span>
        </button>
        {caps?.webgl && (
          <button
            className="switcher-tool"
            aria-pressed={!lite}
            aria-label={lite ? "Enable 3D effects" : "Switch to lite mode (disable 3D)"}
            title={lite ? "3D off" : "3D on"}
            onClick={() => setLite(!lite)}
          >
            <span className="text-[10px] font-bold tracking-wider">{lite ? "2D" : "3D"}</span>
          </button>
        )}
      </div>
    </nav>
  );
}
